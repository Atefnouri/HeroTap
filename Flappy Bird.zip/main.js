// Initialize Phaser and creates a game
var game = new Phaser.Game(400, 600, Phaser.AUTO, 'gameDiv');
var bird;
var pipe;
var score;
var scoreTxt;

// Creates a new 'main' state that will contain the game
var mainState = {

    // Function for loading all assets of the game (called only once)
    preload: function() { 
    //do all the scaling
    if(!game.device.desktop)
    {
    game.scale.fullScreenScaleMode = Phaser.ScaleManager.EXACT_FIT;
    game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    game.scale.setScreenSize(true);    
    }else
    {
    game.scale.fullScreenScaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.setScreenSize(true);    
    }    
        
    game.load.image('bird','assets/bird.png');
    game.load.image('pipe','assets/pipe.png');
 
        
    },

    // Fuction called o after 'preload' to setup the game (called only once)
    create: function() {
        
        game.stage.backgroundColor = '#3498db';
        bird = game.add.sprite(30,200,'bird');
        pipe = game.add.sprite(500,420,'pipe');
        pipe.passed = false;
        //pipe2 = game.add.sprite(530,180,'pipe');
       // pipe2.scale.y *= -1;
        //setup physics
        game.physics.startSystem(Phaser.Physics.ARCADE);
        game.physics.arcade.enable(bird);
         game.physics.arcade.enable(pipe);
  
         bird.body.gravity.y = 750;
        
        //game input
        game.input.onDown.add(this.jump,this);
        score = 0;
        var style = {font:"20px Arial",fill: "#FFFFFF"};
        scoreTxt = game.add.text(300,25,"Score "+score,style);
    },

    // This function is called 60 times per second
    update: function() {
    
    pipe.body.x-=5;  
  
        
   if(bird.inWorld == false){
    this.restart();
   }
        
    if(pipe.body.x < -(pipe.body.width))
    {
   
    //pipe.body.y =420;
    pipe.body.x =520;  
    score++;    
    scoreTxt.setText("Score "+score);    
   
    } 
        
     
        
      
        
    //colession detection
    game.physics.arcade.overlap(bird,pipe,this.restart,null,this);
      
        
    },
    
    jump : function()
    {
    bird.body.velocity.y = -250;
    },
    
    restart: function()
    {

    game.state.start('main');
    console.log("Restart");

    }
};

//Add and start the 'main' state to start the game
game.state.add('main', mainState);  
game.state.start('main'); 